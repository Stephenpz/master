package com.al.model;

import javax.persistence.Entity;
import org.hibernate.Session;

import com.al.factory.HibernateSessionFactory;

/**
 * Data access object (DAO) for domain model
 * @author MyEclipse Persistence Tools
 */
@Entity
public class BaseHibernateDAO implements IBaseHibernateDAO {
	
	public Session getSession() {
		//FIXME: Implement this method
		return HibernateSessionFactory.getSession();
	}
	
}