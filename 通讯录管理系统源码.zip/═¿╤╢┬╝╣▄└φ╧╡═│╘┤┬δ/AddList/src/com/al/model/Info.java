package com.al.model;

/**
 * Info entity. @author MyEclipse Persistence Tools
 */

public class Info implements java.io.Serializable {

	// Fields

	private String name;
	private String tel;
	private String address;
	private String mail;
	private String qq;

	// Constructors

	/** default constructor */
	public Info() {
	}

	/** full constructor */
	public Info(String name, String tel, String address, String mail, String qq) {
		this.name = name;
		this.tel = tel;
		this.address = address;
		this.mail = mail;
		this.qq = qq;
	}

	// Property accessors

	public String getName() {
		return this.name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getTel() {
		return this.tel;
	}

	public void setTel(String tel) {
		this.tel = tel;
	}

	public String getAddress() {
		return this.address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getMail() {
		return this.mail;
	}

	public void setMail(String mail) {
		this.mail = mail;
	}

	public String getQq() {
		return this.qq;
	}

	public void setQq(String qq) {
		this.qq = qq;
	}

}