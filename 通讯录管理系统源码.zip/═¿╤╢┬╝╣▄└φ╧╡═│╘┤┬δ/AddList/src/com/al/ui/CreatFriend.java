package com.al.ui;

import java.awt.EventQueue;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.persistence.Entity;
import javax.persistence.ManyToOne;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;

import com.al.model.Info;
import com.al.service.MainService;

@Entity
public class CreatFriend extends JFrame {

	private JPanel contentPane;
	@ManyToOne
	private MainService mainService;
	private JTextField name, tel, add, mail, qq;
	@ManyToOne
	private Info friendinfo;
	private int temp;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					CreatFriend frame = new CreatFriend();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public CreatFriend() {
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 230, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		// contentPane.setLayout(new BorderLayout(0, 0));
		setContentPane(contentPane);
		setTitle("������ϵ��");
		contentPane.setLayout(null);

		mainService = new MainService();

		JLabel label = new JLabel("����");
		label.setBounds(15, 20, 54, 15);
		contentPane.add(label);

		JLabel label_2 = new JLabel("�绰");
		label_2.setBounds(15, 100, 54, 15);
		contentPane.add(label_2);

		JLabel psw_1 = new JLabel("סַ");
		psw_1.setBounds(15, 60, 54, 15);
		contentPane.add(psw_1);

		JLabel label_3 = new JLabel("����");
		label_3.setBounds(15, 140, 54, 15);
		contentPane.add(label_3);

		JLabel lblQq = new JLabel("QQ");
		lblQq.setBounds(15, 183, 54, 15);
		contentPane.add(lblQq);

		name = new JTextField();
		name.setBounds(70, 20, 137, 21);
		contentPane.add(name);
		name.setColumns(10);

		tel = new JTextField();
		tel.setBounds(70, 97, 137, 21);
		contentPane.add(tel);
		tel.setColumns(10);

		add = new JTextField();
		add.setBounds(70, 57, 137, 21);
		contentPane.add(add);
		add.setColumns(10);

		mail = new JTextField();
		mail.setColumns(10);
		mail.setBounds(70, 140, 137, 21);
		contentPane.add(mail);

		qq = new JTextField();
		qq.setBounds(70, 180, 137, 21);
		contentPane.add(qq);
		qq.setColumns(10);

		JButton btn_ok = new JButton("ȷ��");
		btn_ok.setBounds(28, 221, 70, 30);
		contentPane.add(btn_ok);

		btn_ok.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				if (addnewFriend()) {
					if (temp == 1) {

						if (mainService.addFriend(friendinfo)) {
							JOptionPane.showMessageDialog(null, "������ϵ�˳ɹ���",
									"��ʾ", JOptionPane.INFORMATION_MESSAGE);
							CreatFriend.this.dispose();
						}
						else
						{
							JOptionPane.showMessageDialog(null, "������ϵ��ʧ�ܣ�",
									"��ʾ", JOptionPane.ERROR_MESSAGE);
						}

					} else if (temp == 2) {
						if (mainService.modifyFriend(friendinfo)) {
							JOptionPane.showMessageDialog(null, "�޸���ϵ�˳ɹ���",
									"��ʾ", JOptionPane.INFORMATION_MESSAGE);
							CreatFriend.this.dispose();
						}
						else
						{
							JOptionPane.showMessageDialog(null, "�޸���ϵ��ʧ�ܣ�",
									"��ʾ", JOptionPane.ERROR_MESSAGE);
						}
					}
				}
			}
		});

		JButton btn_cancel = new JButton("ȡ��");
		btn_cancel.setBounds(120, 221, 70, 30);

		btn_cancel.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				CreatFriend.this.dispose();
			}
		});
		contentPane.add(btn_cancel);

	}

	public CreatFriend(int temp, Info info) {
		this();
		this.temp = temp;
		// this.name = name;
		if (temp == 1) {
			this.friendinfo = new Info();
		} else if (temp == 2) {
			this.friendinfo = info;
			initDate();
		}
	}

	public boolean addnewFriend() {
		if (this.name.getText().toString().length() == 0) {
			JOptionPane.showMessageDialog(null, "���벻��Ϊ��", "��ʾ",
					JOptionPane.ERROR_MESSAGE);
			return false;
		}
		if (this.tel.getText().toString().length() == 0) {
			JOptionPane.showMessageDialog(null, "���벻��Ϊ��", "��ʾ",
					JOptionPane.ERROR_MESSAGE);
			return false;
		}
		if (this.add.getText().toString().length() == 0) {
			JOptionPane.showMessageDialog(null, "���벻��Ϊ��", "��ʾ",
					JOptionPane.ERROR_MESSAGE);
			return false;
		}
		if (this.mail.getText().toString().length() == 0) {
			JOptionPane.showMessageDialog(null, "���벻��Ϊ��", "��ʾ",
					JOptionPane.ERROR_MESSAGE);
			return false;
		}
		if (this.qq.getText().toString().length() == 0) {
			JOptionPane.showMessageDialog(null, "���벻��Ϊ��", "��ʾ",
					JOptionPane.ERROR_MESSAGE);
			return false;
		}
		String name = this.name.getText().toString();
		String tel = this.tel.getText().toString();
		String add = this.add.getText().toString();
		String mail = this.mail.getText().toString();
		String qq = this.qq.getText().toString();
		friendinfo .setAddress(add);
		friendinfo.setMail(mail);
		friendinfo.setName(name);
		friendinfo.setQq(qq);
		friendinfo.setTel(tel);
		return true;
	}

	public void initDate() {
		this.name.setText(friendinfo.getName().toString());
		this.name.setEditable(false);
		this.tel.setText(friendinfo.getTel().toString());
		this.add.setText(friendinfo.getAddress().toString());
		this.mail.setText(friendinfo.getMail().toString());
		this.qq.setText(friendinfo.getQq().toString());
	}
}
