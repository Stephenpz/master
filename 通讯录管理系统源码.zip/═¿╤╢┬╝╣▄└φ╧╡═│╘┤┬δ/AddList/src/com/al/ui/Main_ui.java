package com.al.ui;

import java.awt.EventQueue;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.persistence.Entity;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import com.al.model.Info;

@Entity
public class Main_ui extends JFrame {

	private JPanel contentPane;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Main_ui frame = new Main_ui();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Main_ui() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		setTitle("ͨѶ¼����ϵͳ");
		setLocation(500,200);
		setSize(463, 370);
		
		JButton btnNewButton = new JButton("�½���ϵ��");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				addFriend();
			}
		});
		btnNewButton.setBounds(90, 89, 105, 23);
		contentPane.add(btnNewButton);
		
		JButton btnNewButton_1 = new JButton("������ϵ��");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				FindFriend findFriend=new FindFriend();
				findFriend.setVisible(true);
			}
		});
		btnNewButton_1.setBounds(262, 89, 105, 23);
		contentPane.add(btnNewButton_1);
		
		JButton btnNewButton_2 = new JButton("ɾ����ϵ��");
		btnNewButton_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				DeleteFriend deleteFriend=new DeleteFriend();
				deleteFriend.setVisible(true);
			}
		});
		btnNewButton_2.setBounds(90, 155, 105, 23);
		contentPane.add(btnNewButton_2);
		
		JButton btnNewButton_3 = new JButton("�޸���Ϣ");
		btnNewButton_3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				InputName creatFriend=new InputName();
				creatFriend.setVisible(true);
			}
		});
		btnNewButton_3.setBounds(262, 155, 105, 23);
		contentPane.add(btnNewButton_3);
		
		JLabel label = new JLabel("\u901A\u8BAF\u5F55\u7BA1\u7406\u7CFB\u7EDF");
		label.setBounds(178, 10, 107, 35);
		contentPane.add(label);
		
	}
	public void addFriend() {
		Info info = new Info();
		CreatFriend creatfriend = new CreatFriend(1,null);
		creatfriend.setVisible(true);
	}
}

