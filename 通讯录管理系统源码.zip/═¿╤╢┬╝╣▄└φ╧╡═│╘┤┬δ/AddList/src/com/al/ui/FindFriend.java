package com.al.ui;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JButton;

import com.al.model.Info;
import com.al.service.MainService;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class FindFriend extends JFrame {

	private JPanel contentPane;
	private JTextField inputname;
    private MainService mainService;
    private JLabel friend_name ;
    private JLabel friend_tel;
    private JLabel friend_address;
    private JLabel friend_qq ;
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					FindFriend frame = new FindFriend();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public FindFriend() {
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 238, 277);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel label = new JLabel("\u8F93\u5165\u59D3\u540D");
		label.setBounds(38, 28, 54, 15);
		contentPane.add(label);
		mainService=new MainService();
		
		
		inputname = new JTextField();
		inputname.setBounds(102, 26, 96, 18);
		contentPane.add(inputname);
		inputname.setColumns(10);
		
		JButton findFriend = new JButton("\u67E5\u627E");
		findFriend.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(inputname.getText().toString().length()==0)
				{
					JOptionPane.showMessageDialog(null, "����������", "��ʾ", JOptionPane.ERROR_MESSAGE);
				}
				else
				{
					String name=inputname.getText().toString();
					Info info=mainService.getFriendByName(name);
					if(info==null)
					{
						JOptionPane.showMessageDialog(null, "����ʧ��", "��ʾ", JOptionPane.INFORMATION_MESSAGE);
					}
					else
					{
						friend_name.setText("������"+info.getName());
						friend_address.setText("סַ��"+info.getAddress());
						friend_qq.setText("QQ��"+info.getQq());
						friend_tel.setText("�绰��"+info.getTel());
					}
				}
			}
		});
		findFriend.setBounds(21, 191, 93, 23);
		contentPane.add(findFriend);
		
		friend_name = new JLabel("\u59D3\u540D\uFF1A");
		friend_name.setBounds(38, 69, 160, 15);
		contentPane.add(friend_name);
		
		 friend_tel = new JLabel("\u7535\u8BDD\uFF1A");
		friend_tel.setBounds(38, 94, 160, 15);
		contentPane.add(friend_tel);
		
		friend_address = new JLabel("\u4F4F\u5740\uFF1A");
		friend_address.setBounds(38, 122, 160, 15);
		contentPane.add(friend_address);
		
		friend_qq = new JLabel("QQ\uFF1A");
		friend_qq.setBounds(38, 148, 160, 15);
		contentPane.add(friend_qq);
		
		JButton back = new JButton("\u8FD4\u56DE");
		back.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				FindFriend.this.dispose();
			}
		});
		back.setBounds(124, 191, 93, 23);
		contentPane.add(back);
		
	}
}
