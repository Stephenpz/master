package com.al.ui;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JButton;

import com.al.model.Info;
import com.al.service.MainService;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class InputName extends JFrame {

	private JPanel contentPane;
	private JTextField textField;
private MainService mainService;
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					InputName frame = new InputName();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public InputName() {
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 239, 156);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel label = new JLabel("\u8F93\u5165\u59D3\u540D\uFF1A");
		label.setBounds(10, 27, 68, 15);
		contentPane.add(label);
		
		mainService=new MainService();
		
		textField = new JTextField();
		textField.setBounds(88, 24, 94, 21);
		contentPane.add(textField);
		textField.setColumns(10);
		
		JButton button = new JButton("\u786E\u5B9A");
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(textField.getText().toString().length()==0)
				{
					JOptionPane.showMessageDialog(null, "�������û���", "��ʾ", JOptionPane.ERROR_MESSAGE);
				}
				else
				{
					String name=textField.getText().toString();
					if(mainService.getFriendByName(name)!=null)
					{
						Info info=mainService.getFriendByName(name);
						CreatFriend creatFriend=new CreatFriend(2, info);
						creatFriend.setVisible(true);
					}
					else
					{
						JOptionPane.showMessageDialog(null, "������ϵ��ʧ��", "��ʾ", JOptionPane.ERROR_MESSAGE);
					}
				}
			}
		});
		button.setBounds(10, 78, 93, 23);
		contentPane.add(button);
		
		JButton button_1 = new JButton("\u53D6\u6D88");
		button_1.setBounds(120, 78, 93, 23);
		button_1.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				InputName.this.dispose();
			}
		});
		contentPane.add(button_1);
	}

}
