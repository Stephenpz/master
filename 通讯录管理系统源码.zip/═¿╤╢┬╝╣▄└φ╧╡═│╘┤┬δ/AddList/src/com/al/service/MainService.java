package com.al.service;

import javax.persistence.Entity;
import javax.persistence.ManyToOne;
import javax.swing.JOptionPane;

import org.hibernate.Session;

import com.al.factory.HibernateSessionFactory;
import com.al.model.Info;
import com.al.model.InfoDAO;

@Entity
public class MainService {
	@ManyToOne
	private InfoDAO infoDAO;
	public Session session;

	public MainService() {
		session = HibernateSessionFactory.getSession();
		infoDAO = new InfoDAO();
	}

	public boolean addFriend(Info friendinfo) {
		// TODO Auto-generated method stub
		try {
			infoDAO.save(friendinfo);
			return true;
		} catch (NumberFormatException e) {
			// TODO: handle exception

			JOptionPane.showMessageDialog(null, "����ʧ��\n�����ʽ����", "��ʾ",
					JOptionPane.ERROR_MESSAGE);
			return false;
		}
		
	}
	public Info getFriendByName(String name)
	{
		try {
			Info info=infoDAO.findById(name);
			return info;
		} catch (Exception e) {
			// TODO: handle exception
			
			return null;
			
		}
	}
	public boolean delete(String name)
	{
		try {
			Info info=infoDAO.findById(name);
			infoDAO.delete(info);
			return true;
		} catch (Exception e) {
			// TODO: handle exception
			return false;
		}
	}
	public boolean modifyFriend(Info info)
	{
		try {
			infoDAO.attachDirty(info);
			return true;
		} catch (Exception e) {
			// TODO: handle exception
			return false;
		}
		
	}

}
